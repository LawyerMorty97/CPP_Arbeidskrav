This project is using CLion (with MinGW, GNU 8.2.0)

Libraries Used:
- SDL2
- ImGUI
- ImGUI for SDL2

Project Works on:
- Windows
- Linux
- MacOS (Requires sdl2 installed via brew)