# C++ Arbeidskrav
SDL Work Requirement

Build Status: [![Build Status](http://build.mathiastb.no/job/SDL%20Arbeidskrav/badge/icon)](http://build.mathiastb.no/job/SDL%20Arbeidskrav/)
